You must first add a admin manually on the add Database then that admin will be able to register the other admins. Or run the loadBookStore.php script to set up databases
Default admin login details: username = admin1@example.com and password = password
Default user login details: username = j.doe@abc.co.za and password = password

The login_form is the main page of the application. From there both admin and user can login.
Here's the link http://localhost/login_form.php or http://localhost/BookStore/login_form.php as a user.
To login as admin use this link  http://localhost/login_admin.php or http://localhost/BookStore/login_admin.php 

The admin and user pages are seperate so depending if you had registered as a user or admin. You will directed to the according pages. It doesn't make sense for admins to login to user pages and users to attempt to login as admins.

The user directory has all the user scripts:
    > The cart.php script is responsible for displaying and handling cart related functionality. Such viewing and editing cart.
    > The checkout.php script is responsible for checking you out and saving the users order to the database.
    > The editItem.php is responsible for editing item a item that is inside a cart.
    > The orderHistory.php is responsible for displaying all the orders you placed.
    > The shopBooks.php is responsible for displaying the available books and allowing you to add books to cart.
    > The stillValidating.php is responsibe for letting users know if the account is still waiting to be validated by admins.
    > The user_page.php is the landing page for a user after logging in.

The scripts directory has all the scripts for creating the db tables and adding admin and user details:
    > The createTable.php scripts only creates the user table
    > The loadBookStore.php script is responsible creating the tables need for the application and load them with default data.

The admin directory has the admin sctipts (only admin user can access these scripts) :
    > The acceptStudents.php script is the one that valids students and enables them to login
    > The addBook.php script is where you as admin can add books to the store.
    > The addNewAdmin.php script is where you can add new admins but only and existing admin can add another admin.
    > The addStudents.php scripts is where you can view, reject or add new students.
    > The admin_page.php is the landing page for admins after logging in
    > The bookShop.php is where you can manage the book store by adding, editing or removing books
    > The rejectStudent.php is the script responsible for rejecting students that try to register as users.
    > The updateBook.php script is where you can update book details.
    > The updateStudent.php script is where you can update Student details

The DataFiles dir has all the data that is uploaded into the db tables when executing the loadBookStore.php script inside the scripts directory.

It's worth noting that not every script is accessible directly, some have to be triggered or called from other scripts as they may need some parameteres so they access they assigned functionality. 

