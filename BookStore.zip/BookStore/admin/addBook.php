<?php

@include '../DBConn.php';
session_start();


if (isset($_POST['submit'])) {

    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $tmp = $_FILES['image']['name'];
    $image = "../images/$tmp";
    move_uploaded_file($_FILES['image']['tmp_name'], $image);

    $select = " SELECT * FROM tblbooks WHERE LOWER(book_title) = LOWER('$title') && LOWER(author_name) = LOWER('$author')";
    $result = mysqli_query($conn, $select);

    if (mysqli_num_rows($result) > 0) {
        $error[] = 'Book already exist!';
    } else {
        //add admin to db and redirect back to admin main page
        $insert = "INSERT INTO tblbooks (book_title, author_name, price, quantity, image) VALUES('$title','$author','$price','$quantity', '$image')";
        if ($conn->query($insert) !== TRUE) {
            echo "Error updating book data from tblbook: " . $conn->error;
        } else {
            echo '<script>alert("Success! The operation was completed successfully.");</script>';
        }
    }
};
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add new book</title>

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">

</head>

<body>

    <div class="form-container">

        <form action="" method="POST" enctype="multipart/form-data">
            <h3>Add new book</h3>
            <?php
            if (isset($error)) {
                foreach ($error as $error) {
                    echo '<span class="error-msg">' . $error . '</span>';
                };
            };
            ?>
            <label for="title">Enter book title</label>
            <input type="text" name="title" required placeholder="enter the book title name">
            <label for="author">Enter author</label>
            <input type="text" name="author" required placeholder="enter the author">
            <label for="price">Enter price</label>
            <input type="number" name="price" required placeholder="enter the price of the book">
            <label for="quantity">Enter quantity available</label>
            <input type="number" name="quantity" required placeholder="enter quantity available">
            <label for="image">Select image</label>
            <input type="file" name="image" required>
            <input type="submit" name="submit" value="Add book" class="form-btn">
            <a class="btn btn-primary btn-block" href='./bookShop.php'>Back</a>

        </form>

    </div>

</body>

</html>