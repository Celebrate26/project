<?php
@include '../DBConn.php';
session_start();


$email = $_GET["email"];

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
   //Get the user details from db so we can populate the form
   $sql = "SELECT * FROM tbluser WHERE email = '$email'";
   $resultUser = mysqli_query($conn, $sql);
   $row = mysqli_fetch_array($resultUser);

   $username = $row["username"];
   $email = $row["email"];
   $stdNumber = $row["stdNumber"];
} else {
   //get the new updated details from the form and push them to db
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $pass = md5($_POST['password']);
   $cpass = md5($_POST['cpassword']);

   $sql = "UPDATE tbluser SET username='$name',password='$pass', WHERE email='$email'";
   $resultUser = mysqli_query($conn, $sql);
   header('location:./addStudents.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/style.css">

</head>

<body>

   <div class="form-container">

      <form action="" method="POST">
         <h3>Update user <?php $email ?></h3>
         <?php
         if (isset($error)) {
            foreach ($error as $error) {
               echo '<span class="error-msg">' . $error . '</span>';
            };
         };
         ?>
         <input type="text" name="name" required placeholder="enter your name">
         <input type="password" name="password" required placeholder="enter your password">
         <input type="password" name="cpassword" required placeholder="confirm your password">
         <input type="submit" name="submit" value="Update user" class="form-btn">
      </form>

   </div>

</body>

</html>