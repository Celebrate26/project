<?php
@include '../DBConn.php';
session_start();

if (isset($_GET['action'])) {
    if ($_GET['action'] == 'remove') {
        $book_id = @$_GET["book_id"];
        $sql = "Delete FROM tblbooks WHERE book_id='$book_id'";
        if ($conn->query($sql) !== TRUE) {
            echo "Error removing book data from tblbook: " . $conn->error;
        }
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage books</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">

</head>

<body>
    <div class="container my-5">
        <h3>Manage Books</h3>

        <a class="btn btn-primary btn-sm" href='./addBook.php'>Add New Book</a>

        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>Book title</th>
                    <th>Author</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                //Selects all users from the db and displays them in a table
                $select = " SELECT * FROM tblbooks ";
                $result = mysqli_query($conn, $select);

                while ($row = $result->fetch_assoc()) {
                    echo "
                        <tr>
                            <td>$row[book_title]</td>
                            <td>$row[author_name]</td>
                            <td>$row[price]</td>
                            <td>$row[quantity]</td>
                            <td>
                                <a class=\"btn btn-primary btn-sm\" href='./updateBook.php?book_id=$row[book_id]'>Update</a>
                                <a class=\"btn btn-danger btn-sm\" href='./bookShop.php?action=remove&book_id=$row[book_id]'>Remove</a>
                            </td>
                        </tr>";
                }
                ?>

            </tbody>
        </table>
    </div>

</body>

</html>