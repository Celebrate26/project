<?php
@include '../DBConn.php';

session_start();

$email = $_GET["email"];
//Updated the user as a verified user on the db
$sql = "UPDATE tbluser SET stdValid = 'y' WHERE email = '$email'";
$resultUser = mysqli_query($conn, $sql);

header('location:./addStudents.php');

?>