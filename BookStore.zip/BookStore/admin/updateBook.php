<?php
@include '../DBConn.php';
session_start();

$book_id = $_GET["book_id"];
$book_title = "";
$price = 0;
$quantity = 0;

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    //Get the book details from db so we can populate the form
    $sql = "SELECT * FROM tblbooks WHERE book_id = '$book_id'";
    $resultUser = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($resultUser);

    $book_title = $row["book_title"];
    $author = $row["author_name"];
    $price = $row["price"];
    $quantity = $row["quantity"];
} else {
    //get the new updated details from the form and push them to db
    $price = $_POST["price"];
    $quantity = $_POST["quantity"];

    $sql = "UPDATE tblbooks SET price='$price', quantity='$quantity' WHERE book_id=$book_id";
    if ($conn->query($sql) !== TRUE) {
        echo "Error updating book data from tblbook: " . $conn->error;
    } else {
        echo '<script>alert("Success! The operation was completed successfully.");</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Book</title>

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">


</head>

<body>

    <div class="form-container">

        <form action="" method="POST">
            <h3>Update book: <?php echo $book_title ?></h3>
            <?php
            if (isset($error)) {
                foreach ($error as $error) {
                    echo '<span class="error-msg">' . $error . '</span>';
                };
            };
            ?>
            <label for="price">Price</label>
            <input type="number" name="price" required placeholder="enter your new book price" value="<?= $price ?>">
            <label for="quantity">Quantity</label>
            <input type="number" name="quantity" required placeholder="enter quantity of books available" value="<?= $quantity ?>">
            <input type="submit" name="submit" value="Update book" class="form-btn">
            <a class="btn btn-primary btn-block" href='./bookShop.php'>Back</a>
        </form>

    </div>

</body>

</html>