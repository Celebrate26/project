<?php

@include '../DBConn.php';
session_start();


if (isset($_POST['submit'])) {

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   //hash the password
   $pass = md5($_POST['password']);
   $cpass = md5($_POST['cpassword']);
   $stdNumber = $_POST['stdNumber'];

   $select = " SELECT * FROM tbladmin WHERE email = '$email' && username = '$name'";
   $result = mysqli_query($conn, $select);

   if (mysqli_num_rows($result) > 0) {

      $error[] = 'user already exist!';
   } else {
      //check if passwords match
      if ($pass != $cpass) {
         $error[] = 'password not matched!';
      } else {
         //add admin to db and redirect back to admin main page
         $insert = "INSERT INTO tbladmin (username, email, password, stdNumber) VALUES('$name','$email','$pass','$stdNumber')";
         mysqli_query($conn, $insert);
         header('location:./admin_page.php');
      }
   }
};
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Add new admin</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/style.css">

</head>

<body>

   <div class="form-container">

      <form action="" method="POST">
         <h3>Register new admin</h3>
         <?php
         if (isset($error)) {
            foreach ($error as $error) {
               echo '<span class="error-msg">' . $error . '</span>';
            };
         };
         ?>
         <input type="text" name="name" required placeholder="enter your name">
         <input type="email" name="email" required placeholder="enter your email">
         <input type="text" name="stdNumber" required placeholder="enter your student number">
         <input type="password" name="password" required placeholder="enter your password">
         <input type="password" name="cpassword" required placeholder="confirm your password">
         <input type="submit" name="submit" value="register admin" class="form-btn">
      </form>

   </div>

</body>

</html>