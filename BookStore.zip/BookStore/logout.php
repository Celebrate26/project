<?php

@include 'DBConn.php';
//logout user and terminate db connection
session_start();
session_unset();
session_destroy();

header('location:login_form.php');

?>