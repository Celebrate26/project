<?php

@include 'DBconn.php';

session_start();


if (!isset($_SESSION['user_name'])) {
   header('location:../login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>user page</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/style.css">

</head>

<body>

   <div class="container">

      <!--display info for users if they have been verified. -->
      <div class="content">
         <h3>Hi, <span>user</span></h3>
         <h1>Welcome <span><?php echo $_SESSION['user_name'] ?></span></h1>
         <p>You account has been verified. New features coming soon.</p>
         <a href="../user/shopBooks.php" class="btn">shop books</a>
         <a href="../user/orderHistory.php" class="btn">Order History</a>
         <a href="../logout.php" class="btn">logout</a>
      </div>

   </div>

</body>

</html>