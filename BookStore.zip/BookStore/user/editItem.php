<?php
@include '../DBConn.php';
session_start();
$session_array_id = array_column($_SESSION['cart'], "book_id");
$book_title = "";

foreach ($_SESSION['cart'] as $key => $value) {
    if ($value['book_id'] == $_GET['book_id']) {
        // Update the quantity value
        $book_title = $_SESSION['cart'][$key]["book_title"];
        break;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST'  && in_array($_GET['book_id'], $session_array_id)) {
    foreach ($_SESSION['cart'] as $key => $value) {
        if ($value['book_id'] == $_GET['book_id']) {
            // Update the quantity value
            $_SESSION['cart'][$key]['quantity'] = $_POST['quantity'];
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update item</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">

</head>

<body>

    <div class="form-container">

        <form action="" method="POST">
            <h3>Update book order for: <?php echo $book_title ?></h3>
            <?php
            if (isset($error)) {
                foreach ($error as $error) {
                    echo '<span class="error-msg">' . $error . '</span>';
                };
            };
            ?>
            <label for="quantity">Quantity</label>
            <input type="number" name="quantity" min="1" value="1" max="3" class="form-control">
            <input type="submit" name="submit" value="Update book" class="form-btn">
            <a class="btn btn-primary btn-block" href='cart.php'>Back</a>
        </form>

    </div>

</body>

</html>