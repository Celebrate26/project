<?php
@include '../DBConn.php';
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <h2 class="text-center">Checkout</h2>
    <table class='table table-boarded table-striped'>
        <tr>
            <th>Order reference number</th>
            <th>Number of books ordered</th>
            <th>Order date</th>
            <th>Total Price</th>
        </tr>

        <?php
        $output = "";
        $userID = "";
        $total = 0;
        $todayDate = date("d/m/Y");
        $sessionId = session_id();

        $sql = "SELECT user_id FROM tbluser WHERE username='" . $_SESSION['user_name'] . "'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            $row = $result->fetch_assoc();
            $userID = $row['user_id'];
        }

        if (!empty($_SESSION['cart'])) {

            echo "<p>***Order has been succesfully placed</p>";
            foreach ($_SESSION['cart'] as $key => $value) {
                $output .= "
                <tr>
                <td>" . $sessionId . "</td>
                <td>" . $value['quantity'] . "</td>
                <td>" . $todayDate . "</td>
                <td>R " . number_format($value['price'] * $value['quantity'], 2) . "</td>
                </tr>";
                $total = $total + $value['quantity'] * $value['price'];
                //Add order to the order table
                $sql =  "INSERT INTO `tblaorder`(`order_ref`, `user_id`, `book_id`, `quantity`, `order_date`) VALUES ('$sessionId','$userID','" . $value['book_id'] . "','" . $value['quantity'] . "','$todayDate')";
                if ($conn->query($sql) !== TRUE) {
                    echo "<br>Error inserting into tblaorder: " . $conn->error;
                }
            }

            $output .= "
                <tr>
                    <td colspan='2'></td>
                    <td>Total Price:</td>
                    <td>R " . number_format($total, 2) . "</td>
                </tr>
                <tr>
                    <td colspan='3'></td>
                    <td>
                        <a href='../logout.php' class='btn btn-primary btn-block'>Done</a>
                    </td>
                </tr>";

            echo $output;
        } else {
            echo "<p>You have no items checked out </p>";
            echo "<a href='shopBooks.php' class='btn btn-primary btn-block'>Continue Shopping</a>";
        }

        ?>
    </table>
</body>

</html>