<?php
@include '../DBConn.php';
session_start();

if (isset($_POST['add_to_cart'])) {
    if (isset($_SESSION['cart'])) {
        $session_array_id = array_column($_SESSION['cart'], "book_id");

        if (!in_array($_GET['book_id'], $session_array_id)) {
            $_SESSION['cart'][] = array(
                'book_id' => $_GET['book_id'],
                'book_title' => $_GET['book_title'],
                'price' => $_GET['price'],
                'author' => $_GET['author'],
                'quantity' => $_POST['quantity']
            );
        } else if (in_array($_GET['book_id'], $session_array_id)) {
            foreach ($_SESSION['cart'] as $key => $value) {
                if ($value['book_id'] == $_GET['book_id']) {
                    // Update the quantity value
                    $_SESSION['cart'][$key]['quantity'] = $value['quantity'] + $_POST['quantity'];
                    break;
                }
            }
        }
    } else {
        $_SESSION['cart'][] = array(
            'book_id' => $_GET['book_id'],
            'book_title' => $_GET['book_title'],
            'author' => $_GET['author'],
            'price' => $_GET['price'],
            'quantity' => $_POST['quantity']
        );
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
</head>

<body>
    <div>
        <h3 class="text-center">Books available</h3>
    </div>

    <hr>
    <div class="col-md-12">

        <div class="row">
            <?php
            $select = " SELECT * FROM tblbooks ";
            $result = mysqli_query($conn, $select);

            while ($row = $result->fetch_assoc()) { ?>
                <div class="col-md-4">
                    <form action="shopBooks.php?book_id=<?= $row['book_id'] ?>&price=<?= $row['price'] ?>&author=<?= $row['author_name'] ?>&book_title=<?= $row['book_title'] ?>" method="POST">
                        <img src="<?= $row['image'] ?>" alt='image of book'>
                        <h5><?= $row['book_title'] ?></h5>
                        <h5><?= $row['price'] ?></h5>
                        <h6><?= $row['author_name'] ?></h5>
                            <input type="number" name="quantity" value="1" max="2" class="form-control">
                            <input type="submit" name="add_to_cart" class="btn btn-warning btn-block my-2" value="Add to Cart">
                            <a class="btn btn-primary btn-block my-2" href="cart.php">View Cart</a>
                    </form>
                </div>
            <?php
            }
            ?>
        </div>
    </div>
    </div>
</body>

</html>