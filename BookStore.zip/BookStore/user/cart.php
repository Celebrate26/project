<?php
@include '../DBConn.php';
session_start();

if (isset($_GET['action'])) {
    if ($_GET['action'] == 'clear') {
        unset($_SESSION['cart']);
    }

    if ($_GET['action'] == 'remove') {
        foreach ($_SESSION['cart'] as $key => $value) {
            if ($value['book_id'] == $_GET['book_id']) {
                unset($_SESSION['cart'][$key]);
            }
        }
    }


}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <h2 class="text-center">Items inside cart</h2>
    <div class="col-md-12">
        <?php
        $total = 0;
        $output = "";
        $output .= "<table class='table table-boarded table-striped'>
            <tr>
                <th>Book title</th>
                <th>Author</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Action</th>
            </tr>";

        if (!empty($_SESSION['cart'])) {

            foreach ($_SESSION['cart'] as $key => $value) {
                $output .= "
            <tr>
                <td>" . $value['book_title'] . "</td>
                <td>" . $value['author'] . "</td>
                <td>R " . $value['price'] . "</td>
                <td>" . $value['quantity'] . "</td>
                <td>R " . number_format($value['price'] * $value['quantity'], 2) . "</td>
                <td>
                    <a class='btn btn-danger btn-sm' href='cart.php?action=remove&book_id=" . $value['book_id'] . "'>Remove</a>
                    <a class='btn btn-secondary btn-sm' href='editItem.php?action=update&book_id=" . $value['book_id'] . "'>Update</a>
                </td>
            </tr>";
                $total = $total + $value['quantity'] * $value['price'];
            }
        }

        $output .= "
        <tr>
            <td colspan='3'></td>
            <td>Total Price</td>
            <td>R " . number_format($total, 2) . "</td>
            <td>
                <a href='checkout.php' class='btn btn-success btn-block'>Checkout</a>
                <a href='cart.php?action=clear' class='btn btn-warning btn-block'>Clear Cart</a>
                <a href='shopBooks.php' class='btn btn-primary btn-block'>Continue Shopping</a>
            </td>
        </tr>
        ";

        echo $output;
        ?>

    </div>

</body>

</html>