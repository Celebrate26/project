<?php
@include '../DBConn.php';
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order history</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <h2 class="text-center">Order history</h3>
        <table class='table table-boarded table-striped'>
            <tr>
                <th>Order Date</th>
                <th>Order reference</th>
                <th>Quantity</th>
                <th>Book title</th>
                <th>Author</th>
                <th>Total</th>
            </tr>

            <?php
            $sql = "SELECT user_id FROM tbluser WHERE username='" . $_SESSION['user_name'] . "'";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                $row = $result->fetch_assoc();
                $userID = $row['user_id'];
            }

            $total = 0;

            $sql = "SELECT * from tblaorder WHERE user_id='$userID'";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                while ($row = $result->fetch_assoc()) {
                    $total = $total + 1;
            ?>
                    <!-- Get the order reference, quantity, order date, book id -->
                    <tr>
                        <td><?= $row['order_date'] ?></td>
                        <td><?= $row['order_ref'] ?></td>
                        <td><?= $row['quantity'] ?></td>

                        <?php $book_sql = "SELECT * from tblbooks WHERE book_id='" . $row['book_id'] . "'";
                        $book_result = mysqli_query($conn, $book_sql);
                        if ($book_result) {
                            while ($book_row = $book_result->fetch_assoc()) { ?>
                                <td><?= $book_row['book_title'] ?></td>
                                <td><?= $book_row['author_name'] ?></td>
                                <td><?= number_format($book_row['price'] * $row['quantity'], 2)  ?></td>
                        <?php
                            }
                        }
                        ?>
                    </tr>
            <?php
                }
                echo  "<tr>
                    <td colspan='4'></td>
                    <td>Total no. of books purchased</td>
                    <td>" . $total . "</td>
                </tr>";
            }
            ?>

            <tr>
                <td colspan="5"></td>
                <td>
                    <a href='shopBooks.php' class='btn btn-primary btn-block'>Continue Shopping</a>
                </td>
            </tr>
        </table>

</body>

</html>