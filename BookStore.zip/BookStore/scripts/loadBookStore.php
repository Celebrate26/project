<?php

@include "../DBConn.php";

$sql = "CREATE TABLE `tbluser` (
    `user_id` int(11) NOT NULL  AUTO_INCREMENT PRIMARY KEY,
    `username` varchar(50) NOT NULL,
    `password` varchar(50) NOT NULL,
    `email` varchar(100) NOT NULL,
    `stdNumber` varchar(256) NOT NULL,
    `stdValid` text NOT NULL DEFAULT 'n'
  )";
if ($conn->query($sql) !== TRUE) {
  echo "Error creating table tbluser: " . $conn->error;
} else {
  echo "Table tbluser created";
  // Load data from the userData.txt file
  $data = file("../DataFiles/userData.txt");
  foreach ($data as $line) {
    $fields = explode(",", $line);
    $username = trim($fields[0]);
    $email = trim($fields[1]);
    $password = trim($fields[2]);
    $stdNumber = trim($fields[3]);
    // Insert data into the tblUser table
    $sql = "INSERT INTO tbluser (username, email, password, stdNumber, stdValid)
  VALUES ('$username', '$email', '$password', '$stdNumber', 'y')";

    if ($conn->query($sql) !== TRUE) {
      echo "Error loading data into tblUser: " . $conn->error;
      break;
    } else {
      echo "<br>tbluser populated with data";
    }
  }
}

$sql = "CREATE TABLE `tbladmin` (
    `admin_id` int(11) NOT NULL  AUTO_INCREMENT PRIMARY KEY,
    `username` varchar(50) NOT NULL,
    `password` varchar(50) NOT NULL,
    `email` varchar(100) NOT NULL
  )";
if ($conn->query($sql) !== TRUE) {
  echo "<br>Error creating table tbladmin: " . $conn->error;
} else {
  echo "<br>Table tbladmin created";
  // Load data from the userData.txt file
  $data = file("../DataFiles/adminData.txt");
  foreach ($data as $line) {
    $fields = explode(",", $line);
    $username = trim($fields[0]);
    $password = trim($fields[1]);
    $email = trim($fields[2]);
    // Insert data into the tblUser table
    $sql = "INSERT INTO tbladmin (username, email, password)
  VALUES ('$username', '$email', '$password')";

    if ($conn->query($sql) !== TRUE) {
      echo "Error loading data into tbladmin: " . $conn->error;
      break;
    } else {
      echo "<br>tbladmin populated with data";
    }
  }
}

$sql = "CREATE TABLE `tblbooks` (
    `book_id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `book_title` varchar(100) NOT NULL,
    `author_name` varchar(100) NOT NULL,
    `price` decimal(10,2) NOT NULL,
    `quantity` int(255) NOT NULL,
    `image` varchar(256) NOT NULL
  )";
if ($conn->query($sql) !== TRUE) {
  echo "<br>Error creating table tblbooks: " . $conn->error;
} else {
  echo "<br>Table tblbooks created";
  $data = file("../DataFiles/booksData.txt");
  foreach ($data as $line) {
    $fields = explode(",", $line);
    $book_title = trim($fields[0]);
    $author_name = trim($fields[1]);
    $price = trim($fields[2]);
    $image = trim($fields[3]);
    $quantity = trim($fields[4]);
    // Insert data into the tblUser table
    $sql = "INSERT INTO tblbooks (book_title, author_name, price, quantity, image)
  VALUES ('$book_title', '$author_name', '$price', '$quantity', '$image')";

    if ($conn->query($sql) !== TRUE) {
      echo "Error loading data into tblbooks: " . $conn->error;
      break;
    } else {
      echo "<br>tblbooks populated with data";
    }
  }
}

$sql = "CREATE TABLE `tblaorder` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `order_date` varchar(256) NOT NULL,
  `order_ref` varchar(256) NOT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `tbluser` (`user_id`),
  FOREIGN KEY (`book_id`) REFERENCES `tblbooks` (`book_id`)
)";

if ($conn->query($sql) !== TRUE) {
  echo "<br>Error creating table tblaorder: " . $conn->error;
} else {
  echo "<br>Table tablaorder created";
}
