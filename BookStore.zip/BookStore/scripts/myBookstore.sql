-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 06:57 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`admin_id`, `username`, `password`, `email`) VALUES
(1, 'admin1', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin1@example.com'),
(2, 'admin2', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin2@example.com'),
(3, 'admin3', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin3@example.com'),
(4, 'admin4', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin4@example.com'),
(5, 'admin5', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin5@example.com');

-- --------------------------------------------------------

--
-- Table structure for table `tblaorder`
--

CREATE TABLE `tblaorder` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `order_date` varchar(256) NOT NULL,
  `order_ref` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblaorder`
--

INSERT INTO `tblaorder` (`order_id`, `user_id`, `book_id`, `quantity`, `order_date`, `order_ref`) VALUES
(1, 1, 2, 1, '08/06/2023', 'bn4l1sjji8qkc7fm1n56psp15j'),
(2, 1, 3, 1, '08/06/2023', 'bn4l1sjji8qkc7fm1n56psp15j'),
(3, 1, 2, 1, '09/06/2023', 'bn4l1sjji8qkc7fm1n56psp15j'),
(4, 1, 2, 1, '09/06/2023', 'bn4l1sjji8qkc7fm1n56psp15j'),
(5, 1, 3, 1, '09/06/2023', 'bn4l1sjji8qkc7fm1n56psp15j'),
(6, 1, 1, 1, '09/06/2023', 'bn4l1sjji8qkc7fm1n56psp15j');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooks`
--

CREATE TABLE `tblbooks` (
  `book_id` int(11) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(255) NOT NULL,
  `image` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblbooks`
--

INSERT INTO `tblbooks` (`book_id`, `book_title`, `author_name`, `price`, `quantity`, `image`) VALUES
(1, 'Learning Java', 'Daniel Leuck', 25155.00, 51, '../images/t1.jpeg'),
(2, 'Beginning Programming', 'Barry Burd', 150.00, 5, '../images/t2.jpeg'),
(3, 'php and mysql', 'Murach', 300.00, 5, '../images/t3.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `stdNumber` varchar(256) NOT NULL,
  `stdValid` text NOT NULL DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`user_id`, `username`, `password`, `email`, `stdNumber`, `stdValid`) VALUES
(1, 'John Doe', '5f4dcc3b5aa765d61d8327deb882cf99', 'j.doe@abc.co.za', '111111111', 'y'),
(2, 'Jane Smith', '5f4dcc3b5aa765d61d8327deb882cf99', 'j.smith@xyz.com', '222222222', 'y'),
(3, 'Mike Johnson', '37f6b36e5562799570a0dfed8f9361a3', 'm.johnson@pqr.net', '3333333', 'y'),
(4, 'Sarah Lee', '45c86af9d659d44c0cf7aa8b1e872a1d', 's.lee@mno.org', '5555555', 'y'),
(5, 'Tom Brown', '9e257c9d0449071df09a10a0f98ec099', 't.brown@lmn.co.uk', '4444444', 'y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tblaorder`
--
ALTER TABLE `tblaorder`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `tblbooks`
--
ALTER TABLE `tblbooks`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblaorder`
--
ALTER TABLE `tblaorder`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblbooks`
--
ALTER TABLE `tblbooks`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblaorder`
--
ALTER TABLE `tblaorder`
  ADD CONSTRAINT `tblaorder_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbluser` (`user_id`),
  ADD CONSTRAINT `tblaorder_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `tblbooks` (`book_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
