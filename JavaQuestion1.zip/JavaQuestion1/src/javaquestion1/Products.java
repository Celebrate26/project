/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaquestion1;

import java.util.ArrayList;
import java.util.Scanner;


public class Products {
    
    public  void displayMenuOptions(Products products) {
        System.out.println("");
        Scanner read = new Scanner(System.in);
        
        System.out.println("Please select one of the following:");
        System.out.println("(1) Capture a new product" + "\n(2) Search for a product" + "\n(3) Update a product"
        + "\n(4) Delete a product" + "\n(5) Print a report" + "\n(6) Exit Application");
        
        System.out.print(">>>   ");
        String menuSelection = read.nextLine();
        
        if(menuSelection.matches("1")){
            newProduct(products);
        } 
        else if( menuSelection.matches("2")){
            searchProduct(products);
        } 
        else if (menuSelection.matches("3")){
            updateProduct(products);
        } 
        else if (menuSelection.matches("4")){
            deleteProduct(products);
        }
        else if (menuSelection.matches("5")){
            printReport(products);
        }
        else if (menuSelection.matches("6")){
            System.out.println("Thank you for using our programme");
        }
        else{
            System.out.println("Please a valid option");
            displayMenuOptions(products);
        }
                
    }
    
    //This method captures the new products
    public  void newProduct(Products products) {
        Scanner read = new Scanner(System.in);

        System.out.println("");
        
        System.out.println("CAPTURE A NEW PRODUCT");
        System.out.println("**************************");
        System.out.print("Enter products code: >>> ");
        String code = read.nextLine();
        
        System.out.print("Enter product name: >>> ");
        String name = read.nextLine();
        
        System.out.println("");
        
        String categorySelection = "";
        while(categorySelection != "1" || categorySelection != "2" || categorySelection != "3" || categorySelection != "4" || categorySelection != "5" ){
            System.out.println("Select the product category");
            System.out.println("(1) Desktop Computer" + "\n(2) Laptops" + "\n(3) Tablets" + "\n(4) Printer" 
                    + "\n(5) Gaming consoles");
        
            System.out.println("");
            System.out.print("Product category: >>> ");
            categorySelection = read.nextLine();
            
            if(categorySelection.matches("1")){
                categorySelection = "Desktop Computer";
                break;
            } else if(categorySelection.matches("2")){
                categorySelection = "" + "Laptop";
                break;
            } else if(categorySelection.matches("3")){
                categorySelection = "tablet";
                break;
            } else if(categorySelection.matches("4")){
                categorySelection = "printer";
                break;
            } else if(categorySelection.matches("5")){
                categorySelection = "gaming console";
                break;
            } else{
                continue;
            }
        }
        
        System.out.print("Indictae the product warranty. Enter (1) for 6 months or any other key for 2 years. >>> ");
        String warrantyPeriod = read.nextLine();
        
        if(warrantyPeriod.matches("1")){
            warrantyPeriod = "6 months";
        } else {
            warrantyPeriod = "2 years";
        }
        
        System.out.print("Enter the product price: >>> ");
        double price = read.nextDouble();
        
        System.out.print("Enter the product stock level: >>> ");
        int productStockLevel = read.nextInt();
        read.nextLine();
        
        System.out.print("Enter the product supplier: >>> ");
        String supplier = read.nextLine();
        
        saveProduct(code,name,categorySelection,warrantyPeriod,productStockLevel,price,supplier,products);
        
        
    }
    
    public  void searchProduct(Products products) {
        Scanner read = new Scanner(System.in);
        
        
        System.out.print("Please enter product code to search: >>> ");
        String productCode = read.nextLine();
        
        System.out.println("***********************************");
        System.out.println("PRODUCTS SEARCH RESULTS");
        System.out.println("***********************************");

        if (products.code.contains(productCode)){ 
            
            for(int i = 0; i < products.code.size(); i++){
            String code = (String) products.code.get(i);

            if(code.equalsIgnoreCase(productCode)){

                System.out.println("PRODUCT CODE:\t" + products.code.get(i));
                System.out.println("PRODUCT NAME:\t" + products.products.get(i));
                System.out.println("PRODUCT WARRANTY:\t" + products.warranty.get(i) );
                System.out.println("PRODUCT CATEGORY:\t" + products.category.get(i));
                System.out.println("PRODUCT PRICE:\t" + products.price.get(i));
                System.out.println("STOCK LEVELS:\t" + products.stockLevel.get(i));
                System.out.println("PRODUCT SUPPLIER:\t" + products.supplier.get(i));
                break;
            } 
        }} else {
            System.out.println("The code could not be found. Invalid Product.");
        }
        
        
        
        System.out.println("***********************************");
        
        System.out.println("Enter (1) to launch menu or any other key to exit.");
        String menu = read.nextLine();
        
        if(menu.matches("1")){
            displayMenuOptions(products);
        } else{
            System.out.println("Thank you for using our programme");
                    
        }
    }

    public  void updateProduct(Products products) {
        Scanner read = new Scanner(System.in);
        
        
        System.out.print("Please enter product code to search: >>> ");
        String productCode = read.nextLine();
        
        if (products.code.contains(productCode)){ 
            
            for(int i = 0; i < products.code.size(); i++){
            String code = (String) products.code.get(i);
                        
            if(code.equalsIgnoreCase(productCode)){
                System.out.println("1. Update warranty " + "\n2. Update the product price" + "\n3. Update the stock leve");
                String update = read.nextLine();
                
                if(update.matches("1")){
                    System.out.println("Please enter the new warranty period");
                    String warranty = read.nextLine();
                    
                    if(warranty.matches("1")){
                        warranty = "6 months";
                    } else {
                        warranty = "2 years";
                    }
                    
                    products.warranty.set(i, warranty);
                    System.out.println("Update successful");
                    displayMenuOptions(products);
                    
                } else if(update.matches("2")){
                    System.out.println("Please enter the new price");
                    double price = read.nextDouble();
                    products.price.set(i, price);
                    System.out.println("Update successful");
                    displayMenuOptions(products);
                    
                } else if(update.matches("3")){
                    System.out.println("Please enter the stock level");
                    int stocklevel = read.nextInt();
                    products.stockLevel.set(i, stocklevel);
                    System.out.println("Update successful");
                    displayMenuOptions(products);
                    
                } else{
                    System.out.println("Invalid option");
                    displayMenuOptions(products);
                    
                }
                
                break;
            } 
        }} else {
            System.out.println("The code could not be found. Invalid Product.");
        }
    }

    public  void deleteProduct(Products products) {
        Scanner read = new Scanner(System.in);
        System.out.println("Please enter the code of the product you wanr to delete");
        String code = read.nextLine();
        
        if (products.code.contains(code)){ 
            
            System.out.println("delete works");
            for(int i = 0; i < products.code.size(); i++){
            String check = (String) products.code.get(i);

            
            if(check.equalsIgnoreCase(code)){
                products.code.remove(i);
                products.category.remove(i);
                products.price.remove(i);
                products.products.remove(i);
                products.stockLevel.remove(i);
                products.supplier.remove(i);
                products.warranty.remove(i);
                break;
            } 
        }} else {
            System.out.println("The code could not be found. Invalid Product.");
        }
    }

    public void printReport(Products products) {
        
        int count = 1;
        double totalPrice = 0;
        
        System.out.println("************************************");
        System.out.println("PRODUCT REPORT");
        System.out.println("====================================");

        //This loop will print the products
        for(int i = 0; i < products.code.size(); i++){
                System.out.println("PRODUCT " + count );
                System.out.println("--------------------------------------");
                System.out.println("PRODUCT CODE:\t" + products.code.get(i));
                System.out.println("PRODUCT NAME:\t" + products.products.get(i));
                System.out.println("PRODUCT WARRANTY:" +products.warranty.get(i));
                System.out.println("PRODUCT CATEGORY:" + products.category.get(i));
                System.out.println("PRODUCT PRICE:\t" + products.price.get(i));
                System.out.println("STOCK LEVELS:\t" + products.stockLevel.get(i));
                System.out.println("PRODUCT SUPPLIER:\t" + products.supplier.get(i));
                System.out.println("--------------------------------------");
                count = count + 1;
                totalPrice = totalPrice + products.price.get(i);
         }

        System.out.println("====================================");
        System.out.println("TOTAL PRODUCT COUNT:\t" + (count-1));
        System.out.println("TOTAL PRODUCT VALUE:\t" + totalPrice);
        System.out.println("AVERAGE PRODUCT VALUE:\t" + totalPrice/count);
    }
    
    public  void saveProduct(String code, String name, String categorySelection, String warrantyPeriod, int productStockLevel, double price, String supplier, Products products) {
        Scanner read = new Scanner(System.in);

        //These lines sets the values.
        products.setProductCode(code);
        products.setProductName(name);
        products.setProductCategory(categorySelection);
        products.setProductWarranty(warrantyPeriod);
        products.setProductPrice(price);
        products.setProductSupplier(supplier);
        products.setProductStockLevel(productStockLevel);  
        
        //These lines sets the array values.
        products.code.add(code);
        products.products.add(name);
        products.category.add(categorySelection);
        products.warranty.add(warrantyPeriod);
        products.supplier.add(supplier);
        products.price.add(price);
        products.stockLevel.add(productStockLevel);
        
        System.out.println("Product details have been saved successfully!!!");
        System.out.println("Enter (1) to launch menu or any other key to exit.");
        String menu = read.nextLine();
        
        //This loop controls whether the user wants to continue using or the programme or sxit
        if(menu.matches("1")){
            displayMenuOptions(products);
        } else{
            System.out.println("Thank you for using our programme");
        }
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductSupplier() {
        return productSupplier;
    }

    public void setProductSupplier(String productSupplier) {
        this.productSupplier = productSupplier;
    }

    public String getProductWarranty() {
        return productWarranty;
    }

    public void setProductWarranty(String productWarranty) {
        this.productWarranty = productWarranty;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public int getProductStockLevel() {
        return productStockLevel;
    }

    public void setProductStockLevel(int productStockLevel) {
        this.productStockLevel = productStockLevel;
    }

    public Products() {
    }
    
    public String productName;
    public String productCode;
    public String productSupplier;
    public String productWarranty;
    public String productCategory;
    public double productPrice;
    public int productStockLevel;

    public ArrayList<String> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<String> products) {
        this.products = products;
    }

    public ArrayList<String> getCode() {
        return code;
    }

    public void setCode(ArrayList<String> code) {
        this.code = code;
    }

    public ArrayList<String> getSupplier() {
        return supplier;
    }

    public void setSupplier(ArrayList<String> supplier) {
        this.supplier = supplier;
    }

    public ArrayList<String> getWarranty() {
        return warranty;
    }

    public void setWarranty(ArrayList<String> warranty) {
        this.warranty = warranty;
    }

    public ArrayList<String> getCategory() {
        return category;
    }

    public void setCategory(ArrayList<String> category) {
        this.category = category;
    }

    public ArrayList<Double> getPrice() {
        return price;
    }

    public void setPrice(ArrayList<Double> price) {
        this.price = price;
    }

    public ArrayList<Integer> getStockLevel() {
        return stockLevel;
    }

    public void setStockLevel(ArrayList<Integer> stockLevel) {
        this.stockLevel = stockLevel;
    }
    
    public ArrayList<String> products = new ArrayList<String>(5);
    public ArrayList<String> code = new ArrayList<String>(5);
    public ArrayList<String> supplier = new ArrayList<String>(5);
    public ArrayList<String> warranty = new ArrayList<String>(5);
    public ArrayList<String> category = new ArrayList<String>(5);
    public ArrayList<Double> price = new ArrayList<Double>(5);
    public ArrayList<Integer> stockLevel = new ArrayList<Integer>(5);
}
