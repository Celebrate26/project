﻿namespace RecipeApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ManageReciepe manageReciepes = new ManageReciepe();

            //run the app until user enter a stop value
            while(true)
            {
                string choice = promptUser();

                if (choice.Equals("1"))
                {
                    manageReciepes.addRecipe();

                } else if (choice.Equals("2"))
                {
                    manageReciepes.scaleRecipe();
                } else if (choice.Equals("3"))
                {
                    manageReciepes.resetRecipe();
                } else if (choice.Equals("4"))
                {
                    manageReciepes.displayRecipe();
                } else if (choice.Equals("5"))
                {
                    manageReciepes.clearRecipeData();
                } else if (choice.Equals("6"))
                {
                    manageReciepes.displayRecipes();
                } else
                {
                    break;
                }
            }
             
        }

        static string promptUser()
        {
            Console.WriteLine("Please selecta a option below:\n1. Capture Recipe\n2. Scale Recipe\n3. Reset scale\n4. Display Recipe\n5. Clear all data\n6. Display all Recipes\n7. Exit");
            String input = Console.ReadLine();

            if (input.Equals("1") || input.Equals("2") || input.Equals("3") || input.Equals("4") || input.Equals("5") || input.Equals("6") || input.Equals("7"))
            {
                return input;
            }

            return promptUser();

        }

    }
}