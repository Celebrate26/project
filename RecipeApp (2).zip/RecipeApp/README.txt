﻿Changes that have been implemented:

Introduced a new class called ManageRecipe which will store all the recieps and keep track of all the 
reciepes. 

The user can now enter unlimited recipes each with a name.

The app displays the list of recipes in alphabetical order.

The user can enter calories and a food group for each ingredient.

The total calories of a recipe is calculated and displayed

The user is alerted when the calories of a recipe exceed 300

The recipes, ingredients and steps are stored in generic collections.

We are now able to view a previously captured reciepe from the list of captured reciepes
