﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    internal class Recipe
    {
        string recipe;
        int numIngr;
        int receipSteps;
        int totalCalories = 0;
        List<string> ingredients;
        List<string> steps;
        List<string> originalIngredients;
        List<int> calories;
        List<string> foodGroup;

        internal string RecipeName { get { return recipe; } }
        internal List<int> Calories { get { return calories; } }
        internal List<string> FoodGroup { get { return foodGroup; } }
        internal int NumIngredients { get { return numIngr; } }
        internal int RecipeSteps { get { return receipSteps; } }
        internal List<string> IngredientsList { get { return ingredients; } }
        internal List<string> StepsList { get { return steps; } }
        internal List<string> OriginalIngredientsList { get { return originalIngredients; } }




        public Recipe()
        {
            ingredients = new List<string>();
            calories = new List<int>();
            foodGroup = new List<string>();
            steps = new List<string>();
            originalIngredients = new List<string>();
        }
        //Capture recipe

        public void captureRecipe()
        {
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("Capture Ingredients");
            Console.WriteLine("------------------------------------------");

            Console.WriteLine("Please enter the name of the recipe");
            recipe = Console.ReadLine();

            try
            {
                Console.WriteLine("Please enter the number of ingredients");
                numIngr = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("How many steps are there to this recipe");
                receipSteps = Convert.ToInt32(Console.ReadLine());
            }
            catch
            {
                Console.Write("Please ensure you enter a literal number eg '2'");
                captureRecipe();
            }

        }

        public void captureIngredients()
        {
            for (int i = 0; i < numIngr; i++)
            {
                Console.WriteLine("\n------------------------------------------");
                Console.WriteLine("Please enter ingredient name:");
                string ingredientName = Console.ReadLine();

                double ingredientQty;
                try
                {
                    Console.WriteLine("Please enter quantity:");
                    ingredientQty = Convert.ToDouble(Console.ReadLine());
                }
                catch
                {
                    i -= 1;
                    Console.WriteLine("Quantity has to be a literal number eg '4' or '4.5'");
                    continue;
                }

                Console.WriteLine("Please enter the unit of measurement");
                string ingredientUnit = Console.ReadLine();
                string ingredient = ingredientName + " " + Convert.ToString(ingredientQty) + " " + ingredientUnit;

                //Add ingredient to list 
                ingredients.Add(ingredient);

                //Call the calculation of calories and passing the delegation method
                totalCalories = calculateCalories(totalCalories, (calories) =>
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Recipe exceed 300 calories!!!!!!");
                    Console.ResetColor();
                });

                foodGroups();

                Console.WriteLine("------------------------------------------\n");
            }
        }

        public delegate void NotifyExceededCalories(int totalCalories);

        //Capture the food group of the ingredient
        private void foodGroups()
        {
            Console.ForegroundColor = ConsoleColor.Blue;

            Console.WriteLine("Please enter ingredient food group below:\n1. Starchy foods - These are our main source of carbohydrates. They are a good source of energy and the main source of a range of nutrient eg >Pap >Samp >Brown >Rice >Potatoes >Whole wheat bread >Whole wheat pasta\n" +
                "\n2. Vegetables and fruits - Vegetables and fruit contain lots of vitamins and minerals that can help prevent diseases and they are also packed with fibre which can help lower cholesterol and helps digestion.\n" +
                "\n3. Dry beans, peas, lentils and soya - These are a good source of fibre, vitamins and minerals and are naturally very low in fat. They can be used as alternatives for meat or chicken because they are a good source of protein and this reduces the amount of fat you’re consuming. eg ?Chickpeas >Kidney beans >Green peas >Black beans >Soy beans >Split peas\n" +
                "\n4. Meat / Chicken/ Fish - A good source of protein, vitamins and minerals.\n" +
                "\n5. Milk and dairy products - Milk and dairy products are good sources of protein and vitamins. They also contain calcium, which helps keep our bones healthy and strong.\n" +
                "\n6. Fats and oils - Some fats are healthier than others, so it’s best to choose unsaturated fats which are plant-based instead of animal-based fats which are saturated fats. eg Avocado \nOlive oil \nNuts and seeds \nFlax seed");
            Console.ResetColor();

            string input = Console.ReadLine();


            if (input.Equals("1") || input.Equals("2") || input.Equals("3") || input.Equals("4") || input.Equals("5") || input.Equals("6"))
            {
                foodGroup.Add(input);
                return;
            }

            foodGroups();
        }

        //Calculates the calories
        private int calculateCalories(int totalCalories, NotifyExceededCalories notify)
        {
            Console.WriteLine("Please enter ingredient calories:");
            int calory = Convert.ToInt32(Console.ReadLine());
            totalCalories += calory;
            calories.Add(calory);
           
            if (totalCalories > 300)
            {
                notify(totalCalories);
            }

            return totalCalories;
        }

        //Captures the steps needed for the recipe
        public void captureSteps()
        {
            Console.WriteLine("\n------------------------------------------");
            Console.WriteLine("\t\t\tCapture steps");
            Console.WriteLine("------------------------------------------");

            for (int i = 0; i < receipSteps; i++)
            {
                Console.WriteLine("Please enter step " + (i + 1));
                string step = "Step " + (i + 1) + " " + Console.ReadLine();
                steps.Add(step);
            }
        }

        //Display recipe to user
        public void displayRecipe()
        {
            Console.ForegroundColor = ConsoleColor.Blue;

            if (recipe == null)
            {
                Console.WriteLine("Please capture a recipe first");
                return;
            }

            Console.WriteLine("\n------------------------------------------");
            Console.WriteLine("\t\t\tReciepe");
            Console.WriteLine("------------------------------------------");

            //Print to user 
            Console.WriteLine("Recipe: " + recipe);

            for (int j = 0; j < ingredients.Count; j++)
            {
                Console.WriteLine("Ingredient " + (j + 1) + ":");
                Console.WriteLine("\t" + ingredients[j]);

                Console.WriteLine("Ingredient calories: ");
                Console.WriteLine("\t" + calories[j]);

                Console.WriteLine("Ingredient food group:");
                Console.WriteLine("\t" + foodGroup[j]);

            }
            Console.WriteLine("Recipe calories: ");
            Console.WriteLine("\t" + totalCalories);


            Console.WriteLine("Steps:");
            for (int k = 0; k < steps.Count; k++)
            {
                Console.WriteLine("\t" + steps[k]);
            }
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("------------------------------------------\n");

            Console.ResetColor();

        }

        //Scales the ingredients
        public void scaleIngredients()
        {
            Console.ForegroundColor = ConsoleColor.Blue;

            Console.WriteLine("\n------------------------------------------");
            Console.WriteLine("\t\t\tScale Ingredient");
            Console.WriteLine("------------------------------------------");

            originalIngredients = new List<string>(ingredients);

            Console.WriteLine("Please factor to scale recipe by:");
            double scale = Convert.ToDouble(Console.ReadLine());

            for (int i = 0; i < ingredients.Count; i++)
            {
                string ingredient = ingredients[i];
                string[] splitIngredients = ingredient.Split();

                double newIngredientQuantity = Convert.ToDouble(splitIngredients[1]) * scale;

                splitIngredients[1] = Convert.ToString(newIngredientQuantity);
                ingredients[i] = string.Join(" ", splitIngredients);
            }
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("------------------------------------------\n");
            Console.ResetColor();


        }

        public void resetIgredients()
        {
            ingredients = new List<string>(originalIngredients);
        }


        internal void clearData()
        {
            recipe = null;
            numIngr = 0;
            receipSteps = 0;
            ingredients.Clear();
            steps.Clear();
            originalIngredients.Clear();
        }
    }
}