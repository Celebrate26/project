﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    internal class ManageReciepe
    {
        List<Recipe> recipes;
        Recipe recipe;
        List<string> recipeNames;

        public ManageReciepe()
        {
            recipes = new List<Recipe>();
        }


        public void addRecipe()
        {
            recipe = new Recipe();
            recipes.Add(recipe);
            recipe.captureRecipe();

            recipe.captureIngredients();

            recipe.captureSteps();

            recipe.displayRecipe();
        }

        public void scaleRecipe()
        {
            recipe.scaleIngredients();
            Console.WriteLine("------------------\nIngredients have been scaled\n---------------");
            recipe.displayRecipe();
        }

        internal void clearRecipeData()
        {
            recipe.clearData();
        }

        internal void displayRecipe()
        {
            recipe.displayRecipe();
        }

        internal void resetRecipe()
        {
            recipe.resetIgredients();
            Console.WriteLine("------------------\nIngredients have been reset to original scale\n---------------");
            recipe.displayRecipe();
        }

        //Displays all recipes in alphabetical order
        internal void displayRecipes()
        {
            Console.ForegroundColor = ConsoleColor.Blue;

            recipeNames = new List<string>();
            foreach (Recipe recipe in recipes)
            {
                recipeNames.Add(recipe.RecipeName);
            }

            // sort the recipe names list in alphabetical order
            recipeNames.Sort();

            Console.WriteLine("All Recieps:");
            int count = 1;
            foreach (string recipeName in recipeNames)
            {
                Console.WriteLine("\t" + count++ +". " +recipeName);
            }

            Console.ResetColor();


            Console.WriteLine("Which reciepe do you want to view: ");
            int choice = Convert.ToInt32 (Console.ReadLine());

            String receipeWanted = recipeNames[choice - 1];
            findReciep(receipeWanted);

        }
        //Searches for the requested recipe and displays to user
        internal void findReciep(String recipeWanted)
        {
            foreach (string recipeName in recipeNames)
            {
                if (recipeName.Equals(recipeWanted))
                {
                    foreach (Recipe recipe in recipes)
                    {
                        if (recipe.RecipeName.Equals(recipeWanted)){
                            recipe.displayRecipe();
                        }
                    }
                }
            }
        }
    }
}
