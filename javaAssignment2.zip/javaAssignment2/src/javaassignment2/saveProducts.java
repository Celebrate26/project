/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaassignment2;

import java.util.ArrayList;

public class saveProducts {

    public saveProducts() {
    }
    
    public ArrayList<String> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<String> products) {
        this.products = products;
    }

    public ArrayList<Integer> getProductsPice() {
        return productsPice;
    }

    public void setProductsPice(ArrayList<Integer> productsPice) {
        this.productsPice = productsPice;
    }

    
    public ArrayList<String> products = new ArrayList<String>(5);
    public ArrayList<Integer> productsPice = new ArrayList<Integer>(5);
    
}
