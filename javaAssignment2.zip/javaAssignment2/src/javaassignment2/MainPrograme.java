/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates1

 * and open the template in the editor.
 */
package javaassignment2;

import java.util.Scanner;

public class MainPrograme {

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner read = new Scanner(System.in);
        
        saveProducts saveProducts = new saveProducts();
        
        System.out.println("Spar shopping");
        System.out.println("***************************");

        getShopperDetails(read,saveProducts);      
    }

    private static void printReceipt(double total, int price, saveProducts saveProducts) {
        System.out.println(total = price + total);
        System.out.println(price);
        
        System.out.println("Your receipt");
        System.out.println("=====================");
        
        int count = 0;
        
        for(int i = 0; i < saveProducts.products.size(); i++){
                System.out.println(saveProducts.products.get(i) + "\t" + "R " + saveProducts.productsPice.get(i));
                System.out.println("--------------------------------------");
                count = count + 1;
                total = total + saveProducts.productsPice.get(i);
         }
        
        System.out.println("SUB-TOTAL:\t" + total);
        System.out.println("VAT:\t" + 0.14);
        System.out.println("TOTAL:\t" + (total + (total * 0.14)));
        System.out.println("THANK YOU FOR SHOPPING WITH US.");
        System.out.println("CALL AGAIN!!!");
        
    }

    private static void getShopperDetails(Scanner read, saveProducts saveProducts) {
        String[] Cereal = {"Corn flakes","Weetbix","Rice Crisps","Oats"};
        String[] Fruits = {"Banana","Apples", "Peach","Mango"};
        String[] Vegetables = {"Spinach","Tomato","Pumpkin","Letus"};
        String[] Beverages = {"Orange juice","Sprite","Pepsi","Alchole"};
        int[] productPrice = {20,40,60,80};
        double total = 0;
        int price = 0;
        String product = "";
        
        System.out.println("Please select the category: ");
        System.out.println("1. Cereal" + "\n2. Fruits" + "\n3. Vegetables" + "\n4 Beverages");
        
        String category = read.nextLine();
        
        if(category.matches("1")){
            
            System.out.println("");
            //Displays the products
            System.out.println("Which product do you wish to buy");
            for(int count = 0 ; count < Cereal.length; count++){
                System.out.println(count + 1 + ". " + Cereal[count]);
            }
            String selection = read.nextLine();
            //Converts the string prices to int prices so we can calculate later
            if(selection.matches("1")){
                product = Cereal[0];
                price = productPrice[0];
            }
            else if(selection.matches("2")){
                product = Cereal[1];
                price = productPrice[1];
            }
            else if(selection.matches("3")){
                product = Cereal[2];
                price = productPrice[2];
            }
            else if(selection.matches("4")){
                product = Cereal[3];
                price = productPrice[3];
            }
            else{
                System.out.println("Invalid option.");
            }
            
        } else if(category.matches("2")){
            System.out.println("");
            System.out.println("Which product do you wish to buy");
            for(int count = 0 ; count < Fruits.length; count++){
                System.out.println(count + 1 + ". " + Fruits[count]);
            }
            String selection = read.nextLine();
            //Converts the string prices to int prices so we can calculate later
            if(selection.matches("1")){
                product = Fruits[0];
                price = productPrice[0];
            }
            else if(selection.matches("2")){
                product = Fruits[1];
                price = productPrice[1];
            }
            else if(selection.matches("3")){
                product = Fruits[2];
                price = productPrice[2];
            }
            else if(selection.matches("4")){
                product = Fruits[3];
                price = productPrice[3];
            }
            
        } else if(category.matches("3")){
            System.out.println("");
            System.out.println("Which product do you wish to buy");
            for(int count = 0 ; count < Vegetables.length; count++){
                System.out.println(count + 1 + ". " + Vegetables[count]);
            }
            String selection = read.nextLine();
            //Converts the string prices to int prices so we can calculate later
            if(selection.matches("1")){
                product = Vegetables[0];
                price = productPrice[0];
            }
            else if(selection.matches("2")){
                product = Vegetables[1];
                price = productPrice[1];
            }
            else if(selection.matches("3")){
                product = Vegetables[2];
                price = productPrice[2];
            }
            else if(selection.matches("4")){
                product = Vegetables[3];
                price = productPrice[3];
            }
            else{
                System.out.println("Invalid option.");
            }
            
        } else if(category.matches("4") {
            System.out.println("");
            System.out.println("Which product do you wish to buy");
            for(int count = 0 ; count < Beverages.length; count++){
                System.out.println(count + 1 + ". " + Beverages[count]);
            }
            String selection = read.nextLine();
            //Converts the string prices to int prices so we can calculate later
            if(selection.matches("1")){
                product = Beverages[0];
                price = productPrice[0];
            }
            else if(selection.matches("2")){
                product = Beverages[1];
                price = productPrice[1];
            }
            else if(selection.matches("3")){
                product = Beverages[2];
                price = productPrice[2];
            }
            else if(selection.matches("4")){
                product = Beverages[3];
                price = productPrice[3];
            }
            else{
                System.out.println("Invalid option.");
            }
            
        } else {
            System.out.println("Invalid option");
        }
       
        saveProducts.products.add(product);
        saveProducts.productsPice.add(price);
            
        System.out.println("Do you want to shore more products");
        System.out.println("Enter (1) to shore more or any key to pay.");
                
        String more = read.nextLine();
        
        if(more.matches("1")){            
            getShopperDetails(read,saveProducts);
        } else{
        
            printReceipt(total,price,saveProducts);
        }
    }
    
}
