package mashaba_task2;


import login.Login;
import mashaba.user.data.DeveloperDetails;
import mashaba.user.data.Task;

import javax.swing.*;
import java.util.Scanner;


public class Mashaba_ST10055395_Task_2 {

   public static Scanner sn = new Scanner(System.in);
    public static Login login = new Login();
    public static Task task = new Task();
    public static final String errorMessage = "Username or password incorrect, please try again";
    public static final String signupErrorMessage = "Password successfully captured";

    public static void main(String[] args) {
        programLoop();
    }

    public static boolean tryToLogin() {
        boolean tryLogin = true;
        boolean loginStatus = false;

        while(tryLogin) {

            if (!loginStatus) {
                String username = getInput("Insert username:\n");
                String password = getInput("Insert password:\n");
                String message = login.returnLoginStatus(username, password);
                if (!message.equals(errorMessage)) {
                    loginStatus = true;
                    System.out.println("Welcome to EasyKanban");
                } else {
                    System.out.println(message);
                }

            } else {
                tryLogin = loggedInUser();
            }
        }
        return tryLogin;
    }

    public static boolean loggedInUser() {

        try {
            int selected = Integer.parseInt(getInput("1. Add task \n2. Show report \n3. Quit"));
            switch(selected) {
                case 1:
                    addTask();
                    break;
                case 2:
                    showReport();
                    break;
                case 3:
                    return false;
                default:
                    System.out.print("Input should be between 1 - 3");
            }
        } catch(NumberFormatException e) {
            System.out.println("Please input only numbers");
        }
        return true;
    }

    public static void addTask() {
        int numberOfTasks = Integer.parseInt(getInput("Input number of Tasks:"));

        int i = 0;
        while(i < numberOfTasks) {
            String taskName = getInput("Input task Name:");
            String taskDescription = getInput("Input Task Description:");
            String firstName = getInput("Input developer First Name:");
            String lastName = getInput("Input developer Last Name:");
            DeveloperDetails developerDetails = new DeveloperDetails(firstName, lastName);
            int duration = Integer.parseInt(getInput("Input Task Duration:"));
            String response = task.createTask(taskName, i,taskDescription, developerDetails, duration,"To Do");
            if (response.equals("Task successfully captured")) {
                System.out.println(response);

                JFrame frame = new JFrame();
                String taskId = task.createTaskID(taskName, i++, firstName);
                JOptionPane.showMessageDialog(frame, task.printTaskDetails(taskId));
            } else {
                System.out.println(response);
            }
        }
        System.out.println("Total duration: " + task.returnTotalHours() + "hrs");
    }

    public static void showReport() {
        System.out.println("Coming Soon");
    }

    public static void tryToSignup() {
        boolean trySignup = true;
        while(trySignup) {
            String username = getInput("input Username: ");
            String password = getInput("input Password: ");
            String name = getInput("input Name: ");
            String surname = getInput("input Surname: ");
            String message = login.registerUser(username, password, name, surname);
            if (message.equals(signupErrorMessage))
                trySignup = false;
            System.out.println(message);
        }
    }

    public static void programLoop() {
        boolean loop = true;
        while(loop) {
            try {
                int selected = Integer.parseInt(getInput("1. Login \n2. Signup \n3. exit"));
                switch(selected) {
                    case 1:
                        loop = tryToLogin();
                        break;
                    case 2:
                        tryToSignup();
                        break;
                    case 3:
                        loop = false;
                        break;
                    default:
                        System.out.print("Input should be between 1 - 3");
                }
            } catch(NumberFormatException e) {
                System.out.println("Please input only numbers");
            }
        }
    }

    public static String getInput(String input) {
        System.out.println(input);
        return String.valueOf(sn.nextLine());
    }
}
