﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    internal class Recipe
    {
        string recipe;
        int numIngr;
        int receipSteps;
        string[] ingredients;
        string[] steps;
        string[] originalIngredients;
        public void captureRecipe()
        {
            //Capture recipe
            Console.WriteLine("Please enter the name of the recipe");
            recipe = Console.ReadLine();

            try
            {
                Console.WriteLine("Please enter the number of ingredients");
                numIngr = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("How many steps are there to this recipe");
                receipSteps = Convert.ToInt32(Console.ReadLine());
            }
            catch
            {
                Console.Write("Please ensure you enter a literal number eg '2'");
                captureRecipe();
            }
            
            ingredients = new string[numIngr];

            steps = new string[receipSteps];
        }

        public void captureIngredients()
        {
            for (int i = 0; i < numIngr; i++)
            {
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("Please enter ingredient name:");
                string ingredientName = Console.ReadLine();
                double ingredientQty;
                try
                {
                    Console.WriteLine("Please enter quantity:");
                    ingredientQty = Convert.ToDouble(Console.ReadLine());
                }
                catch
                {
                    i -= 1;
                    Console.WriteLine("Quantity has to be a literal number eg '4' or '4.5'");
                    continue;
                }

                Console.WriteLine("Please enter the unit of measurement");
                string ingredientUnit = Console.ReadLine();
                ingredients[i] = ingredientName + " " + Convert.ToString(ingredientQty) + " " + ingredientUnit;

                Console.WriteLine("------------------------------------------");
            }
        }

        public void captureSteps()
        {

            for (int i = 0; i < receipSteps; i++)
            {
                Console.WriteLine("Please enter step " + (i + 1));
                string step = "Step " + (i + 1) + " " + Console.ReadLine();
                steps[i] = step;
            }
        }

        public void displayRecipe()
        {
            if(recipe == null)
            {
                Console.WriteLine("Please capture a recipe first");
                return;
            }
            //Print to user 
            Console.WriteLine("Recipe: " + recipe);

            for (int j = 0; j < numIngr; j++)
            {
                Console.WriteLine("Ingredient " + (j + 1) + ":");

                Console.WriteLine("\t" + ingredients[j]);
            }
            Console.WriteLine("Steps:");
            for (int k = 0; k < receipSteps; k++)
            {
                Console.WriteLine("\t" + steps[k]);
            }
        }

        public void scaleIngredients()
        {
            originalIngredients = (string[])ingredients.Clone();

            Console.WriteLine("Please factor to scale recipe by:");
            double scale = Convert.ToDouble(Console.ReadLine());

            for (int i = 0; i < ingredients.Length; i++)
            {
                string ingredient = ingredients[i];
                string[] splitIngredients = ingredient.Split();

                double newIngredientQuantity = Convert.ToDouble(splitIngredients[1]) * scale;

                splitIngredients[1] = Convert.ToString(newIngredientQuantity);
                ingredients[i] = string.Join(" ", splitIngredients);
            }
        }

        public void resetIgredients()
        {
            ingredients = originalIngredients;
        }

        internal void clearData()
        {
            string recipe = null;
            int numIngr = 0;
            int receipSteps = 0;
            string[] ingredients = null;
            string[] steps = null;
            string[] originalIngredients = null;
        }
    }
}
