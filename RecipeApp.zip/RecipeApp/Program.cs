﻿namespace RecipeApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            //run the app until user enter a stop value
            while(true)
            {
                string choice = promptUser();

                if (choice.Equals("1"))
                {
                    recipe.captureRecipe();

                    recipe.captureIngredients();

                    recipe.captureSteps();

                    recipe.displayRecipe();
                } else if (choice.Equals("2"))
                {
                    recipe.scaleIngredients();
                    Console.WriteLine("------------------\nIngredients have been scaled\n---------------");
                    recipe.displayRecipe();
                } else if (choice.Equals("3"))
                {
                    recipe.resetIgredients();
                    Console.WriteLine("------------------\nIngredients have been reset to original scale\n---------------");
                    recipe.displayRecipe();
                } else if (choice.Equals("4"))
                {
                    recipe.displayRecipe();
                } else if (choice.Equals("5"))
                {
                    recipe.clearData();
                }
                else
                {
                    break;
                }
            }
             
        }

        static string promptUser()
        {
            Console.WriteLine("Please selecta a option below:\n1. Capture Recipe\n2. Scale Recipe\n3. Reset scale\n4. Display Recipe\n5. Clear all data\n6. Exit");
            String input = Console.ReadLine();

            if (input.Equals("1") || input.Equals("2") || input.Equals("3") || input.Equals("4") || input.Equals("5") || input.Equals("6"))
            {
                return input;
            }

            return promptUser();

        }

    }
}