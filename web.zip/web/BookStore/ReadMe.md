You must first add a admin manually on the add Database then that admin will be able to register the other admins.

The login_form is the main page of the application. From there both admin and user can login.
Here's the link http://localhost/BookStore/login_form.php

The admin and user pages are seperate so depending if you had registered as a user or admin. You will directed to the according pages. It doesn't make sense for admins to login to user pages and users to attempt to login as admins.

