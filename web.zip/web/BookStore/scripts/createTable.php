<?php
include "DBConn.php";

// Check if the tblUser table exists
$result = mysqli_query($conn, "SHOW TABLES LIKE 'tbluser'");
$tableExists = mysqli_num_rows($result) > 0;

if ($tableExists) {
  // Delete the tblUser table
  echo "table exits";
} else {
  mysqli_query($conn, "DROP TABLE tbluser");

}

// Create the tblUser table
$sql = "CREATE TABLE tbluser(
  user_id INT(11) NOT NULL AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL,
  password VARCHAR(50) NOT NULL,
  PRIMARY KEY (user_id)
)";
mysqli_query($conn, $sql);

// Load data from the userData.txt file
$data = file("../DataFiles/userData.txt");
foreach ($data as $line) {
  $fields = explode(",", $line);
  $username = trim($fields[0]);
  $email = trim($fields[1]);
  $password = trim($fields[2]);
  $stdNumber = trim($fields[3]);
  // Insert data into the tblUser table
  $sql = "INSERT INTO tbluser (username, email, password, stdNumber)
  VALUES ('$username', '$email', '$password', '$stdNumber')";
  mysqli_query($conn, $sql);
}

echo "Table created successfully";
?>
