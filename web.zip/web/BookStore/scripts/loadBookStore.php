<?php

@include "../DBConn.php";

$sql = "CREATE TABLE `tbluser` (
    `user_id` int(11) NOT NULL,
    `username` varchar(50) NOT NULL,
    `password` varchar(50) NOT NULL,
    `email` varchar(100) NOT NULL,
    `stdNumber` varchar(256) NOT NULL,
    `stdValid` text NOT NULL DEFAULT 'n'
  )";
mysqli_query($conn, $sql);

$sql = "CREATE TABLE `tbladmin` (
    `admin_id` int(11) NOT NULL,
    `username` varchar(50) NOT NULL,
    `password` varchar(50) NOT NULL,
    `email` varchar(100) NOT NULL
  )";
mysqli_query($conn, $sql);

$sql = "CREATE TABLE `tblbooks` (
    `book_id` int(11) NOT NULL,
    `book_title` varchar(100) NOT NULL,
    `author_name` varchar(100) NOT NULL,
    `publisher_name` varchar(100) NOT NULL,
    `price` decimal(10,2) NOT NULL,
    `quantity` int(255) NOT NULL
  )";
mysqli_query($conn, $sql);

$sql = "CREATE TABLE `tblaorder` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `order_date` datetime NOT NULL
  FOREIGN KEY (book_id) REFERENCES tblbooks(book_id),
  FOREIGN KEY (user_id) REFERENCES tbluser(user_id),
)";
mysqli_query($conn, $sql);
?>