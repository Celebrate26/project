<?php
@include '../DBConn.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Students</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h3>Students that need to be verified</h3>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Student Number</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                //Selects all users from the db and displays them in a table
                    $select = " SELECT * FROM tbluser ";
                    $result = mysqli_query($conn, $select);

                    while($row = $result->fetch_assoc()){
                        echo "
                        <tr>
                            <td>$row[username]</td>
                            <td>$row[email]</td>
                            <td>$row[stdNumber]</td>
                            <td>
                                <a class=\"btn btn-primary btn-sm\" href='./updateStudent.php?email=$row[email]'>Update</a>
                                <a class=\"btn btn-danger btn-sm\" href='./rejectStudent.php?email=$row[email]'>Reject</a>
                                <a class=\"btn btn-primary btn-sm\" href='./acceptStudent.php?email=$row[email]'>Accept</a>
                            </td>
                        </tr>";
                    }
                ?>
                
            </tbody>
        </table>
    </div>
</body>
</html>