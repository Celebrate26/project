<?php
@include '../DBConn.php';

session_start();

$email = $_GET["email"];
//when admin rejects student update the db that student has been rejected
$sql = "UPDATE tbluser SET stdValid = 'r' WHERE email = '$email'";
$resultUser = mysqli_query($conn, $sql);

header('location:./addStudents.php');

?>